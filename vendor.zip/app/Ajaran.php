<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ajaran extends Model
{
    protected $table = 'ajaran';
    protected $guarded = [];
    
}
